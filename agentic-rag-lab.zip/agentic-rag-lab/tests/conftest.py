import pytest

from agentic_rag.config import Settings
from agentic_rag.runtime import build_runtime


@pytest.fixture(scope="session")
def rt():
    return build_runtime(Settings(runs_db=":memory:"))
