import json

import pytest

from agentic_rag.agent import Agent, DecisionError, parse_decision
from agentic_rag.llm import LLMError, MockLLM


class ScriptedLLM:
    """Replays canned model outputs, so agent behaviour is tested without any API."""

    def __init__(self, outputs):
        self.outputs, self.calls = list(outputs), 0

    def next_step(self, question, history, tools):
        out = self.outputs[min(self.calls, len(self.outputs) - 1)]
        self.calls += 1
        if isinstance(out, Exception):
            raise out
        return out


def tool(name, **inp):
    return json.dumps({"action": "tool", "tool": name, "input": inp})


def final(text):
    return json.dumps({"action": "final", "answer": text})


# ------------------------------------------------------------------ parsing


@pytest.mark.parametrize(
    "raw",
    [final("hi"), f"```json\n{final('hi')}\n```", f"Sure! {final('hi')} hope that helps"],
)
def test_parse_tolerates_fences_and_prose(raw):
    assert parse_decision(raw).answer == "hi"


@pytest.mark.parametrize(
    "raw",
    ["", "no json here", "{not json}", "[1, 2]", '{"action": "dance"}',
     '{"action": "tool"}', '{"action": "final", "answer": "  "}'],
)
def test_parse_rejects_invalid(raw):
    with pytest.raises(DecisionError):
        parse_decision(raw)


# ------------------------------------------------------------------ loop behaviour


def test_happy_path_two_tools(rt):
    llm = ScriptedLLM([tool("calculator", expression="6 * 7"), final("It is 42")])
    res = Agent(llm, rt.tools).run("q")
    assert (res.status, res.answer, res.tools_used) == ("ok", "It is 42", ["calculator"])
    assert res.steps[0].observation == "42"


def test_recovers_from_malformed_output(rt):
    llm = ScriptedLLM(["garbage", tool("calculator", expression="1+1"), final("2")])
    res = Agent(llm, rt.tools).run("q")
    assert res.status == "ok" and [s.kind for s in res.steps] == ["error", "tool"]


def test_gives_up_after_repeated_invalid_output(rt):
    res = Agent(ScriptedLLM(["nope"]), rt.tools, max_steps=10, max_invalid=2).run("q")
    assert res.status == "invalid_output" and len(res.steps) == 3


def test_unknown_tool_becomes_observation_not_crash(rt):
    llm = ScriptedLLM([tool("launch_missiles"), final("sorry")])
    res = Agent(llm, rt.tools).run("q")
    assert res.status == "ok" and "Unknown tool" in res.steps[0].error


def test_tool_error_is_fed_back(rt):
    llm = ScriptedLLM([tool("sql_query", query="DROP TABLE sales"), final("cannot")])
    res = Agent(llm, rt.tools).run("q")
    assert res.status == "ok" and "Only SELECT" in res.steps[0].error


def test_duplicate_call_not_executed_twice(rt):
    llm = ScriptedLLM([tool("calculator", expression="1+1")] * 2 + [final("done")])
    res = Agent(llm, rt.tools).run("q")
    assert res.steps[0].observation == "2" and "Duplicate" in res.steps[1].error


def test_max_steps_returns_partial_answer(rt):
    llm = ScriptedLLM([tool("calculator", expression=f"{i}+1") for i in range(20)])
    res = Agent(llm, rt.tools, max_steps=3).run("q")
    assert res.status == "max_steps" and len(res.steps) == 3 and "Last observation" in res.answer


def test_llm_failure_is_reported(rt):
    res = Agent(ScriptedLLM([LLMError("boom")]), rt.tools).run("q")
    assert res.status == "llm_error" and "boom" in res.answer


def test_unexpected_tool_exception_is_contained(rt):
    class Broken:
        def specs(self): return []
        def call(self, name, args): raise RuntimeError("bug")

    res = Agent(ScriptedLLM([tool("x"), final("ok")]), Broken()).run("q")
    assert res.status == "ok" and res.steps[0].error == "internal tool error"


# ------------------------------------------------------------------ offline planner end-to-end


@pytest.mark.parametrize(
    "question,tools,contains",
    [
        ("What is the total revenue in the North region?", ["sql_query"], "702950"),
        ("Which region had the highest revenue?", ["sql_query"], "West"),
        ("What is the total revenue in the North region, and what is 15% of that?",
         ["sql_query", "calculator"], "105442.5"),
        ("What is 20% of 350?", ["calculator"], "70"),
        ("What is walk-forward validation?", ["search_docs"], "[forecast_validation#"),
    ],
)
def test_mock_planner_end_to_end(rt, question, tools, contains):
    res = Agent(MockLLM(), rt.tools).run(question)
    assert res.status == "ok" and res.tools_used == tools and contains in res.answer


def test_result_is_json_serialisable(rt):
    res = Agent(MockLLM(), rt.tools).run("Calculate 2 + 2")
    assert json.dumps(res.to_dict())
