from agentic_rag.agent import Agent
from agentic_rag.cli import main
from agentic_rag.llm import MockLLM
from agentic_rag.store import RunStore


def test_store_roundtrip(rt):
    store = RunStore()
    res = Agent(MockLLM(), rt.tools).run("Calculate 3 * 3")
    run_id = store.add(res)
    run = store.get(run_id)
    assert run["answer"] == res.answer and run["trace"][0]["tool"] == "calculator"
    assert [r["id"] for r in store.list()] == [run_id]
    assert store.get(999) is None


def test_store_list_newest_first_and_limit(rt):
    store = RunStore()
    agent = Agent(MockLLM(), rt.tools)
    ids = [store.add(agent.run(f"Calculate {i} + 1")) for i in range(3)]
    assert [r["id"] for r in store.list(limit=2)] == ids[::-1][:2]


def test_cli_ask_and_search(capsys):
    assert main(["ask", "What is 20% of 350?"]) == 0
    assert "70" in capsys.readouterr().out
    assert main(["search", "docker image layers", "-k", "1"]) == 0
    assert "docker_deployment" in capsys.readouterr().out
