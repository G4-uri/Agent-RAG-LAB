import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")
from fastapi.testclient import TestClient  # noqa: E402

from agentic_rag.api import create_app  # noqa: E402
from agentic_rag.config import Settings  # noqa: E402


@pytest.fixture()
def client():
    return TestClient(create_app(Settings(runs_db=":memory:")))


def test_health(client):
    body = client.get("/health").json()
    assert body["status"] == "ok" and body["chunks"] > 10


def test_search(client):
    r = client.post("/search", json={"query": "what is HNSW", "k": 2, "mode": "bm25"})
    assert r.status_code == 200 and r.json()["results"][0]["chunk_id"].startswith("vector_search")


@pytest.mark.parametrize(
    "payload",
    [{"query": ""}, {"query": "x", "k": 0}, {"query": "x", "k": 99}, {"query": "x", "mode": "magic"}, {}],
)
def test_search_validation(client, payload):
    assert client.post("/search", json=payload).status_code == 422


def test_ask_persists_and_is_retrievable(client):
    r = client.post("/ask", json={"question": "What is 20% of 350?"})
    assert r.status_code == 200 and "70" in r.json()["answer"]
    run_id = r.json()["run_id"]
    assert client.get(f"/runs/{run_id}").json()["status"] == "ok"
    assert client.get("/runs").json()[0]["id"] == run_id
    assert client.get("/runs/9999").status_code == 404


def test_ask_validation(client):
    assert client.post("/ask", json={"question": ""}).status_code == 422
    assert client.post("/ask", json={"question": "x" * 1001}).status_code == 422


def test_api_key_enforced_when_configured():
    client = TestClient(create_app(Settings(runs_db=":memory:", api_key="s3cret")))
    assert client.get("/health").status_code == 200  # health stays public
    assert client.post("/ask", json={"question": "hi"}).status_code == 401
    assert client.post("/ask", json={"question": "hi"}, headers={"X-API-Key": "wrong"}).status_code == 401
    ok = client.post("/ask", json={"question": "Calculate 1 + 1"}, headers={"X-API-Key": "s3cret"})
    assert ok.status_code == 200
