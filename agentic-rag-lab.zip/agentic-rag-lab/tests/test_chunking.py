import pytest

from agentic_rag.chunking import chunk_text, load_corpus
from agentic_rag.config import Settings


def test_chunks_respect_max_words_and_overlap():
    text = " ".join(f"w{i}" for i in range(250))
    chunks = chunk_text(text, "d", "T", max_words=100, overlap=10)
    assert all(len(c.text.split()) <= 100 for c in chunks)
    assert chunks[0].text.split()[-10:] == chunks[1].text.split()[:10]
    covered = {w for c in chunks for w in c.text.split()}
    assert covered == {f"w{i}" for i in range(250)}


def test_no_overlap_only_trailing_chunk():
    text = " ".join(f"w{i}" for i in range(100))
    assert len(chunk_text(text, "d", "T", max_words=100, overlap=10)) == 1


def test_paragraphs_pack_together_and_ids_unique():
    text = "one two three\n\nfour five six\n\nseven eight"
    chunks = chunk_text(text, "doc", "T", max_words=50, overlap=0)
    assert len(chunks) == 1 and chunks[0].chunk_id == "doc#0"


@pytest.mark.parametrize("kwargs", [{"max_words": 0}, {"max_words": 10, "overlap": 10}])
def test_invalid_parameters(kwargs):
    with pytest.raises(ValueError):
        chunk_text("a b c", "d", "T", **kwargs)


def test_load_corpus_titles_and_unique_ids():
    chunks = load_corpus(Settings().corpus_dir)
    ids = [c.chunk_id for c in chunks]
    assert len(ids) == len(set(ids)) and len(chunks) >= 12
    assert {c.title for c in chunks} >= {"Hybrid Retrieval", "Value at Risk (VaR)"}


def test_load_corpus_empty_dir(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_corpus(tmp_path)
