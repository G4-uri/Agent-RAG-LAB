import pytest

from agentic_rag.chunking import Chunk
from agentic_rag.evaluate import hit_at_k, paired_bootstrap_ci, reciprocal_rank
from agentic_rag.retrieval import BM25, Retriever, reciprocal_rank_fusion


def test_bm25_prefers_rare_matching_term():
    docs = [["cat", "sat"], ["dog", "barked", "loud"], ["cat", "cat", "dog"]]
    scores = BM25(docs).scores(["barked"])
    assert scores.argmax() == 1 and scores[0] == 0


def test_bm25_unknown_term_scores_zero():
    assert BM25([["a"], ["b"]]).scores(["zzz"]).sum() == 0


def test_rrf_known_values():
    fused = dict(reciprocal_rank_fusion([[1, 2, 3], [3, 1]], k=60))
    assert fused[1] == pytest.approx(1 / 61 + 1 / 62)
    assert fused[3] == pytest.approx(1 / 63 + 1 / 61)
    assert fused[2] == pytest.approx(1 / 62)
    assert reciprocal_rank_fusion([[1, 2, 3], [3, 1]])[0][0] == 1


def test_rrf_empty():
    assert reciprocal_rank_fusion([[], []]) == []


@pytest.mark.parametrize("mode", ["bm25", "dense", "hybrid"])
def test_search_returns_ranked_hits(rt, mode):
    hits = rt.retriever.search("reciprocal rank fusion of two rankings", k=3, mode=mode)
    assert 1 <= len(hits) <= 3
    assert [h.rank for h in hits] == list(range(1, len(hits) + 1))
    assert hits[0].chunk.doc_id == "hybrid_retrieval"


def test_edge_cases(rt):
    assert rt.retriever.search("   ") == []
    assert rt.retriever.search("qwertyuiop zxcvbnm", mode="bm25") == []
    with pytest.raises(ValueError):
        rt.retriever.search("x", k=0)
    with pytest.raises(ValueError):
        rt.retriever.search("x", mode="nope")  # type: ignore[arg-type]


def test_search_docs_unique_and_limited(rt):
    docs = rt.retriever.search_docs("how to test an agent", k=4)
    assert len(docs) == len(set(docs)) <= 4


def test_retriever_requires_chunks():
    with pytest.raises(ValueError):
        Retriever([])


def test_tiny_corpus_does_not_crash():
    r = Retriever([Chunk("a", "a#0", "A", "alpha beta"), Chunk("b", "b#0", "B", "gamma delta")])
    assert r.search("alpha", mode="hybrid")[0].chunk.doc_id == "a"


def test_metrics():
    assert reciprocal_rank(["x", "y", "z"], ["y"]) == 0.5
    assert reciprocal_rank(["x"], ["q"]) == 0.0
    assert hit_at_k(["x", "y", "z"], ["z"], 2) == 0.0
    assert hit_at_k(["x", "y", "z"], ["z"], 3) == 1.0


def test_bootstrap_ci_contains_mean_and_is_deterministic():
    a, b = [1, 1, 0, 1, 0.5], [0.5, 1, 0, 0.5, 0.5]
    mean, lo, hi = paired_bootstrap_ci(a, b)
    assert lo <= mean <= hi
    assert paired_bootstrap_ci(a, b) == (mean, lo, hi)
