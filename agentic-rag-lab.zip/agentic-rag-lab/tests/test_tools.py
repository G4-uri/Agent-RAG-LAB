import pytest

from agentic_rag.config import Settings
from agentic_rag.tools import ToolError, build_sales_db, calculator, run_sql


@pytest.mark.parametrize(
    "expr,expected",
    [("2 + 3 * 4", "14"), ("(12 + 8) * 3", "60"), ("2 ** 10", "1024"), ("-5 + 2", "-3"),
     ("sqrt(81)", "9"), ("10 / 4", "2.5"), ("7 % 4", "3")],
)
def test_calculator_ok(expr, expected):
    assert calculator(expr) == expected


@pytest.mark.parametrize(
    "expr",
    ["__import__('os').system('echo hi')", "open('x')", "1 / 0", "2 ** 1000", "x + 1",
     "", "1 +", "9" * 300, "(1).__class__", "[1, 2]", "True + 1", "sqrt(-1)"],
)
def test_calculator_rejects_unsafe_or_invalid(expr):
    with pytest.raises(ToolError):
        calculator(expr)


@pytest.fixture()
def db():
    return build_sales_db(Settings().sales_csv)


def test_sql_select_works(db):
    out = run_sql(*db, "SELECT COUNT(*) AS n FROM sales")
    assert out.splitlines() == ["n", "144"]


def test_sql_row_limit(db):
    out = run_sql(*db, "SELECT * FROM sales", max_rows=5)
    assert len(out.splitlines()) == 1 + 5 + 1 and "truncated" in out


@pytest.mark.parametrize(
    "query",
    ["DROP TABLE sales", "DELETE FROM sales", "UPDATE sales SET units = 0",
     "INSERT INTO sales VALUES ('a','b','c',1,1)", "SELECT 1; DROP TABLE sales",
     "PRAGMA query_only = OFF", "ATTACH DATABASE 'x.db' AS x", "", "SELECT nope FROM sales"],
)
def test_sql_rejects_writes_and_errors(db, query):
    with pytest.raises(ToolError):
        run_sql(*db, query)
    assert run_sql(*db, "SELECT COUNT(*) FROM sales").splitlines()[1] == "144"  # data intact


def test_sql_query_only_blocks_writes_even_if_filter_missed(db):
    conn, _ = db
    import sqlite3
    with pytest.raises(sqlite3.OperationalError):
        conn.execute("DELETE FROM sales")


def test_registry_unknown_tool_and_bad_args(rt):
    with pytest.raises(ToolError, match="Unknown tool"):
        rt.tools.call("rm_rf", {})
    with pytest.raises(ToolError, match="Bad arguments"):
        rt.tools.call("calculator", {"wrong": 1})


def test_search_docs_tool(rt):
    out = rt.tools.call("search_docs", {"query": "what is walk-forward validation", "k": 2})
    assert out.startswith("[forecast_validation#")
    assert rt.tools.call("search_docs", {"query": "qwertyuiop"}) == "No relevant passages found."
    with pytest.raises(ToolError):
        rt.tools.call("search_docs", {"query": "x", "k": "many"})
