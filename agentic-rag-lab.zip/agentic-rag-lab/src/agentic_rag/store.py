"""SQLite run log: every agent run is persisted with its full trace."""

from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Any

from .agent import AgentResult


class RunStore:
    def __init__(self, path: str = ":memory:") -> None:
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock:
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS runs ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, "
                "question TEXT NOT NULL, answer TEXT NOT NULL, status TEXT NOT NULL, "
                "latency_ms REAL NOT NULL, trace TEXT NOT NULL)"
            )
            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_runs_created ON runs(created_at)")
            self._conn.commit()

    def add(self, result: AgentResult) -> int:
        trace = json.dumps(result.to_dict()["steps"])
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO runs (created_at, question, answer, status, latency_ms, trace) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    result.question,
                    result.answer,
                    result.status,
                    result.latency_ms,
                    trace,
                ),
            )
            self._conn.commit()
            return int(cur.lastrowid)

    @staticmethod
    def _row(row: sqlite3.Row) -> dict[str, Any]:
        d = dict(row)
        d["trace"] = json.loads(d["trace"])
        return d

    def get(self, run_id: int) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
        return self._row(row) if row else None

    def list(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM runs ORDER BY id DESC LIMIT ?", (max(1, min(limit, 100)),)
            ).fetchall()
        return [self._row(r) for r in rows]
