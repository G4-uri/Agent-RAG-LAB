"""Embedders. The default is offline (TF-IDF + truncated SVD, a.k.a. LSA).

The ``Embedder`` protocol is deliberately tiny so a neural model can be dropped in.
"""

from __future__ import annotations

from typing import Protocol, Sequence

import numpy as np

from .text import tokenize


class Embedder(Protocol):
    def fit(self, texts: Sequence[str]) -> "Embedder": ...

    def encode(self, texts: Sequence[str]) -> np.ndarray:
        """Return an (n, d) array of L2-normalised row vectors."""
        ...


def _l2_normalise(matrix: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    return matrix / np.maximum(norms, 1e-12)  # zero vectors stay zero


class LsaEmbedder:
    """Latent semantic analysis: TF-IDF followed by a low-rank SVD projection.

    Not a neural embedding. It captures term co-occurrence, which gives some
    paraphrase tolerance, and it runs offline with no model download.
    """

    def __init__(self, dims: int = 64, seed: int = 0) -> None:
        self.dims = dims
        self.seed = seed
        self._tfidf = None
        self._svd = None

    def fit(self, texts: Sequence[str]) -> "LsaEmbedder":
        from sklearn.decomposition import TruncatedSVD
        from sklearn.feature_extraction.text import TfidfVectorizer

        self._tfidf = TfidfVectorizer(
            tokenizer=tokenize, lowercase=False, token_pattern=None, sublinear_tf=True
        )
        matrix = self._tfidf.fit_transform(texts)
        n_components = max(1, min(self.dims, matrix.shape[0] - 1, matrix.shape[1] - 1))
        self._svd = TruncatedSVD(n_components=n_components, random_state=self.seed)
        self._svd.fit(matrix)
        return self

    def encode(self, texts: Sequence[str]) -> np.ndarray:
        if self._tfidf is None or self._svd is None:
            raise RuntimeError("Embedder is not fitted; call fit() first")
        return _l2_normalise(self._svd.transform(self._tfidf.transform(texts)))


class SentenceTransformerEmbedder:
    """Optional neural embedder (``pip install sentence-transformers``).

    Not exercised by the default test-suite because it needs a model download.
    """

    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2") -> None:
        from sentence_transformers import SentenceTransformer

        self._model = SentenceTransformer(model_name)

    def fit(self, texts: Sequence[str]) -> "SentenceTransformerEmbedder":
        return self  # pretrained: nothing to fit

    def encode(self, texts: Sequence[str]) -> np.ndarray:
        vectors = self._model.encode(list(texts), normalize_embeddings=True)
        return np.asarray(vectors, dtype=float)
