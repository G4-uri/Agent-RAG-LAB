"""Agentic RAG Lab: hybrid retrieval, a tool-using agent, and honest evaluation."""

__version__ = "0.1.0"
