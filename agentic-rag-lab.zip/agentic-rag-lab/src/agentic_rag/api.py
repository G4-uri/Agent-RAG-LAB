"""FastAPI service. Run with: uvicorn agentic_rag.api:create_app --factory"""

from __future__ import annotations

import hmac
from typing import Any, Literal

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from pydantic import BaseModel, Field

from . import __version__
from .config import Settings
from .llm import LLM
from .runtime import build_runtime


class SearchRequest(BaseModel):
    query: str = Field(min_length=1, max_length=500)
    k: int = Field(default=3, ge=1, le=10)
    mode: Literal["bm25", "dense", "hybrid"] = "hybrid"


class PassageOut(BaseModel):
    chunk_id: str
    title: str
    text: str
    score: float
    rank: int


class SearchResponse(BaseModel):
    query: str
    mode: str
    results: list[PassageOut]


class AskRequest(BaseModel):
    question: str = Field(min_length=1, max_length=1000)


class AskResponse(BaseModel):
    run_id: int
    answer: str
    status: str
    tools_used: list[str]
    latency_ms: float
    steps: list[dict[str, Any]]


def create_app(settings: Settings | None = None, llm: LLM | None = None) -> FastAPI:
    rt = build_runtime(settings, llm)
    api_key = rt.settings.api_key

    def require_key(x_api_key: str | None = Header(default=None)) -> None:
        if api_key and not hmac.compare_digest(x_api_key or "", api_key):
            raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key")

    app = FastAPI(title="Agentic RAG Lab", version=__version__)

    @app.get("/health")
    def health() -> dict[str, Any]:
        return {"status": "ok", "version": __version__, "chunks": len(rt.retriever.chunks)}

    @app.get("/tools", dependencies=[Depends(require_key)])
    def list_tools() -> list[dict[str, Any]]:
        return rt.tools.specs()

    @app.post("/search", response_model=SearchResponse, dependencies=[Depends(require_key)])
    def search(req: SearchRequest) -> SearchResponse:
        hits = rt.retriever.search(req.query, k=req.k, mode=req.mode)
        return SearchResponse(
            query=req.query,
            mode=req.mode,
            results=[
                PassageOut(
                    chunk_id=h.chunk.chunk_id, title=h.chunk.title,
                    text=h.chunk.text, score=round(h.score, 4), rank=h.rank,
                )
                for h in hits
            ],
        )

    @app.post("/ask", response_model=AskResponse, dependencies=[Depends(require_key)])
    def ask(req: AskRequest) -> AskResponse:
        result = rt.agent.run(req.question)
        run_id = rt.store.add(result)
        d = result.to_dict()
        return AskResponse(
            run_id=run_id, answer=result.answer, status=result.status,
            tools_used=result.tools_used, latency_ms=result.latency_ms, steps=d["steps"],
        )

    @app.get("/runs", dependencies=[Depends(require_key)])
    def runs(limit: int = Query(default=20, ge=1, le=100)) -> list[dict[str, Any]]:
        return rt.store.list(limit)

    @app.get("/runs/{run_id}", dependencies=[Depends(require_key)])
    def run_detail(run_id: int) -> dict[str, Any]:
        run = rt.store.get(run_id)
        if run is None:
            raise HTTPException(status_code=404, detail=f"Run {run_id} not found")
        return run

    return app
