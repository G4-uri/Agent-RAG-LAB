"""Wires settings -> retriever -> tools -> agent -> run store."""

from __future__ import annotations

from dataclasses import dataclass

from .agent import Agent
from .chunking import load_corpus
from .config import Settings
from .llm import LLM, build_llm
from .retrieval import Retriever
from .store import RunStore
from .tools import ToolRegistry, build_registry


@dataclass
class Runtime:
    settings: Settings
    retriever: Retriever
    tools: ToolRegistry
    agent: Agent
    store: RunStore


def build_runtime(settings: Settings | None = None, llm: LLM | None = None) -> Runtime:
    settings = settings or Settings.from_env()
    retriever = Retriever(load_corpus(settings.corpus_dir))
    tools = build_registry(retriever, settings.sales_csv)
    agent = Agent(llm or build_llm(settings), tools, max_steps=settings.max_steps)
    return Runtime(settings, retriever, tools, agent, RunStore(settings.runs_db))
