"""BM25, dense vector search and Reciprocal Rank Fusion, behind one Retriever."""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass
from typing import Literal, Sequence

import numpy as np

from .chunking import Chunk
from .embeddings import Embedder, LsaEmbedder
from .text import tokenize

Mode = Literal["bm25", "dense", "hybrid"]
RRF_K = 60


class BM25:
    """Okapi BM25 implemented from scratch (k1 and b are the usual defaults)."""

    def __init__(self, docs: Sequence[Sequence[str]], k1: float = 1.5, b: float = 0.75) -> None:
        self.k1, self.b = k1, b
        self.n_docs = len(docs)
        self.doc_len = np.array([len(d) for d in docs], dtype=float)
        self.avg_len = float(self.doc_len.mean()) if self.n_docs else 1.0
        self.tf = [Counter(d) for d in docs]
        df: Counter[str] = Counter()
        for counts in self.tf:
            df.update(counts.keys())
        self.idf = {
            t: math.log(1 + (self.n_docs - n + 0.5) / (n + 0.5)) for t, n in df.items()
        }

    def scores(self, query_tokens: Sequence[str]) -> np.ndarray:
        out = np.zeros(self.n_docs)
        for token in set(query_tokens):
            idf = self.idf.get(token)
            if idf is None:
                continue
            for i, counts in enumerate(self.tf):
                f = counts.get(token, 0)
                if f:
                    norm = f + self.k1 * (1 - self.b + self.b * self.doc_len[i] / self.avg_len)
                    out[i] += idf * f * (self.k1 + 1) / norm
        return out


def reciprocal_rank_fusion(rankings: Sequence[Sequence[int]], k: int = RRF_K) -> list[tuple[int, float]]:
    """Fuse ranked lists of item ids. Returns (id, fused_score), best first."""
    fused: dict[int, float] = {}
    for ranking in rankings:
        for rank, item in enumerate(ranking, start=1):
            fused[item] = fused.get(item, 0.0) + 1.0 / (k + rank)
    # Ties are broken by id so results are deterministic.
    return sorted(fused.items(), key=lambda kv: (-kv[1], kv[0]))


@dataclass(frozen=True)
class Hit:
    chunk: Chunk
    score: float
    rank: int  # 1-based


class Retriever:
    """In-memory hybrid retriever.

    The dense side is a plain NumPy matrix searched exactly (cosine == dot product on
    unit vectors). For a larger corpus, replace it with a vector database such as
    pgvector, Chroma or Qdrant; the ``search`` contract would not change.
    """

    def __init__(self, chunks: Sequence[Chunk], embedder: Embedder | None = None) -> None:
        if not chunks:
            raise ValueError("Retriever needs at least one chunk")
        self.chunks = list(chunks)
        texts = [c.index_text for c in self.chunks]
        self._bm25 = BM25([tokenize(t) for t in texts])
        self._embedder = embedder or LsaEmbedder()
        self._embedder.fit(texts)
        self._matrix = self._embedder.encode(texts)

    def _rank_bm25(self, query: str) -> list[tuple[int, float]]:
        scores = self._bm25.scores(tokenize(query))
        order = np.argsort(-scores, kind="stable")
        return [(int(i), float(scores[i])) for i in order if scores[i] > 0]

    def _rank_dense(self, query: str) -> list[tuple[int, float]]:
        scores = self._matrix @ self._embedder.encode([query])[0]
        order = np.argsort(-scores, kind="stable")
        return [(int(i), float(scores[i])) for i in order if scores[i] > 1e-9]

    def search(self, query: str, k: int = 3, mode: Mode = "hybrid") -> list[Hit]:
        if k < 1:
            raise ValueError("k must be >= 1")
        if not query.strip():
            return []
        if mode == "bm25":
            ranked = self._rank_bm25(query)
        elif mode == "dense":
            ranked = self._rank_dense(query)
        elif mode == "hybrid":
            ranked = reciprocal_rank_fusion(
                [[i for i, _ in self._rank_bm25(query)], [i for i, _ in self._rank_dense(query)]]
            )
        else:
            raise ValueError(f"unknown mode: {mode!r}")
        return [Hit(self.chunks[i], s, r) for r, (i, s) in enumerate(ranked[:k], start=1)]

    def search_docs(self, query: str, k: int = 3, mode: Mode = "hybrid") -> list[str]:
        """Ranked unique ``doc_id`` list, used by the evaluation harness."""
        seen: list[str] = []
        for hit in self.search(query, k=len(self.chunks), mode=mode):
            if hit.chunk.doc_id not in seen:
                seen.append(hit.chunk.doc_id)
            if len(seen) == k:
                break
        return seen
