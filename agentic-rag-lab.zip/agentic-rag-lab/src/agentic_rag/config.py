"""Runtime configuration read from environment variables (twelve-factor style)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

# Shared with the sample dataset and the offline planner.
REGIONS = ("North", "South", "East", "West")
PRODUCTS = ("Laptop", "Phone", "Tablet")


@dataclass(frozen=True)
class Settings:
    corpus_dir: Path = REPO_ROOT / "data" / "corpus"
    sales_csv: Path = REPO_ROOT / "data" / "sales.csv"
    runs_db: str = ":memory:"  # SQLite path for the run log
    api_key: str | None = None  # if set, the API requires X-API-Key
    llm_provider: str = "mock"  # mock | anthropic | openai
    llm_model: str = ""
    llm_base_url: str = "https://api.openai.com/v1"
    llm_api_key: str | None = field(default=None, repr=False)
    max_steps: int = 5

    @classmethod
    def from_env(cls) -> "Settings":
        env = os.environ
        return cls(
            corpus_dir=Path(env.get("CORPUS_DIR", cls.corpus_dir)),
            sales_csv=Path(env.get("SALES_CSV", cls.sales_csv)),
            runs_db=env.get("RUNS_DB", cls.runs_db),
            api_key=env.get("API_KEY") or None,
            llm_provider=env.get("LLM_PROVIDER", "mock").lower(),
            llm_model=env.get("LLM_MODEL", ""),
            llm_base_url=env.get("LLM_BASE_URL", cls.llm_base_url),
            llm_api_key=env.get("LLM_API_KEY") or None,
            max_steps=int(env.get("MAX_STEPS", cls.max_steps)),
        )
