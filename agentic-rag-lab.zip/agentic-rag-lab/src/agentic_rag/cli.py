"""Command line: ask, search, eval."""

from __future__ import annotations

import argparse
import json
import sys

from .evaluate import run_evaluation
from .runtime import build_runtime


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="agentic-rag", description=__doc__)
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_ask = sub.add_parser("ask", help="run the agent on a question")
    p_ask.add_argument("question")
    p_ask.add_argument("--trace", action="store_true", help="print every step")
    p_search = sub.add_parser("search", help="retrieve passages")
    p_search.add_argument("query")
    p_search.add_argument("-k", type=int, default=3)
    p_search.add_argument("--mode", choices=["bm25", "dense", "hybrid"], default="hybrid")
    sub.add_parser("eval", help="run the evaluation harness")
    args = parser.parse_args(argv)

    rt = build_runtime()
    if args.cmd == "ask":
        result = rt.agent.run(args.question)
        if args.trace:
            print(json.dumps(result.to_dict()["steps"], indent=2))
        print(f"[{result.status}] {result.answer}")
        return 0 if result.status == "ok" else 1
    if args.cmd == "search":
        for hit in rt.retriever.search(args.query, k=args.k, mode=args.mode):
            print(f"{hit.rank}. [{hit.chunk.chunk_id}] ({hit.score:.3f}) {hit.chunk.text[:120]}...")
        return 0
    print(run_evaluation(rt))
    return 0


if __name__ == "__main__":
    sys.exit(main())
