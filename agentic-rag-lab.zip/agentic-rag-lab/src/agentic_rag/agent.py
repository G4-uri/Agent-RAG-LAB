"""The agent loop: decide -> act -> observe, with guardrails and a full trace.

Graph view (one state dict, three nodes), which maps directly onto LangGraph:

    [decide] --tool--> [act] --observation--> [decide]
        |--final--> END           (max_steps / invalid output / llm error also end the run)
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError, model_validator

from .llm import LLM, LLMError
from .tools import ToolError, ToolRegistry

log = logging.getLogger(__name__)

Status = Literal["ok", "max_steps", "invalid_output", "llm_error"]


class Decision(BaseModel):
    action: Literal["tool", "final"]
    tool: str | None = None
    input: dict[str, Any] = Field(default_factory=dict)
    answer: str | None = None

    @model_validator(mode="after")
    def _check(self) -> "Decision":
        if self.action == "tool" and not self.tool:
            raise ValueError("action 'tool' requires a 'tool' name")
        if self.action == "final" and not (self.answer and self.answer.strip()):
            raise ValueError("action 'final' requires a non-empty 'answer'")
        return self


class DecisionError(ValueError):
    """The model output could not be turned into a valid Decision."""


def parse_decision(raw: str) -> Decision:
    """Extract the first JSON object from model text (tolerates code fences and prose)."""
    start = raw.find("{")
    if start == -1:
        raise DecisionError("no JSON object found")
    try:
        obj, _ = json.JSONDecoder().raw_decode(raw[start:])
    except json.JSONDecodeError as exc:
        raise DecisionError(f"invalid JSON: {exc.msg}") from exc
    if not isinstance(obj, dict):
        raise DecisionError("JSON must be an object")
    try:
        return Decision.model_validate(obj)
    except ValidationError as exc:
        raise DecisionError(exc.errors()[0]["msg"]) from exc


@dataclass
class Step:
    kind: Literal["tool", "error"]
    tool: str | None = None
    input: dict[str, Any] = field(default_factory=dict)
    observation: str = ""
    error: str | None = None


@dataclass
class AgentResult:
    question: str
    answer: str
    status: Status
    steps: list[Step]
    latency_ms: float

    @property
    def tools_used(self) -> list[str]:
        return [s.tool for s in self.steps if s.kind == "tool" and s.tool]

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["tools_used"] = self.tools_used
        return d


class Agent:
    def __init__(self, llm: LLM, tools: ToolRegistry, max_steps: int = 5, max_invalid: int = 2) -> None:
        self.llm, self.tools = llm, tools
        self.max_steps, self.max_invalid = max_steps, max_invalid

    def run(self, question: str) -> AgentResult:
        t0 = time.perf_counter()
        steps: list[Step] = []
        seen: set[tuple[str, str]] = set()
        invalid = 0

        def finish(status: Status, answer: str) -> AgentResult:
            ms = round((time.perf_counter() - t0) * 1000, 2)
            return AgentResult(question, answer, status, steps, ms)

        for _ in range(self.max_steps):
            try:
                raw = self.llm.next_step(question, steps, self.tools.specs())
            except LLMError as exc:
                log.warning("LLM backend failed: %s", exc)
                return finish("llm_error", f"The language model backend failed: {exc}")

            try:
                decision = parse_decision(raw)
            except DecisionError as exc:
                steps.append(Step(kind="error", error=str(exc)))
                invalid += 1
                if invalid > self.max_invalid:
                    return finish("invalid_output", "The model repeatedly produced invalid output.")
                continue

            if decision.action == "final":
                return finish("ok", decision.answer or "")

            assert decision.tool is not None
            key = (decision.tool, json.dumps(decision.input, sort_keys=True, default=str))
            if key in seen:  # loop guard: never execute the identical call twice
                steps.append(
                    Step("tool", decision.tool, decision.input,
                         error="Duplicate call; reuse the earlier observation or give a final answer")
                )
                continue
            seen.add(key)
            try:
                steps.append(Step("tool", decision.tool, decision.input,
                                  observation=self.tools.call(decision.tool, decision.input)))
            except ToolError as exc:
                steps.append(Step("tool", decision.tool, decision.input, error=str(exc)))
            except Exception:  # a bug in a tool must not crash the run
                log.exception("Unexpected error in tool %s", decision.tool)
                steps.append(Step("tool", decision.tool, decision.input, error="internal tool error"))

        last = next((s for s in reversed(steps) if s.kind == "tool" and s.observation), None)
        hint = f" Last observation: {last.observation[:200]}" if last else ""
        return finish("max_steps", f"Stopped after {self.max_steps} steps without a final answer.{hint}")
