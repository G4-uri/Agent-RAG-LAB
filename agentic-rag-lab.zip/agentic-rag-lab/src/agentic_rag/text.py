"""Tokenisation shared by BM25 and the embedder."""

from __future__ import annotations

import re

_TOKEN = re.compile(r"[a-z0-9]+")
STOPWORDS = frozenset(
    "a an and are as at be by for from has have how in is it its of on or that the "
    "this to was were what when which who why with do does can i you your".split()
)


def _stem(token: str) -> str:
    """Very small suffix stripper (plurals and -ing/-ed). Enough for a demo corpus."""
    if token.endswith("ies") and len(token) > 4:  # queries -> query
        return token[:-3] + "y"
    for suffix in ("ing", "ed", "es", "s"):
        if token.endswith(suffix) and len(token) - len(suffix) >= 3:
            return token[: -len(suffix)]
    return token


def tokenize(text: str) -> list[str]:
    return [_stem(t) for t in _TOKEN.findall(text.lower()) if t not in STOPWORDS]
