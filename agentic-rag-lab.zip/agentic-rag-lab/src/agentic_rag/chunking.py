"""Load markdown documents and split them into overlapping chunks."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Chunk:
    doc_id: str
    chunk_id: str  # "<doc_id>#<n>"
    title: str
    text: str

    @property
    def index_text(self) -> str:
        """Text used for indexing: the title carries useful keywords."""
        return f"{self.title}. {self.text}"


def chunk_text(
    text: str,
    doc_id: str,
    title: str,
    max_words: int = 90,
    overlap: int = 15,
) -> list[Chunk]:
    """Greedy paragraph packing with a word-level overlap between chunks."""
    if max_words <= 0:
        raise ValueError("max_words must be positive")
    if not 0 <= overlap < max_words:
        raise ValueError("overlap must satisfy 0 <= overlap < max_words")

    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks: list[Chunk] = []
    current: list[str] = []
    fresh = 0  # words added since the last flush (ignores carried overlap)

    def flush(words: list[str]) -> None:
        chunks.append(Chunk(doc_id, f"{doc_id}#{len(chunks)}", title, " ".join(words)))

    for para in paragraphs:
        words = para.split()
        if current and len(current) + len(words) > max_words:
            flush(current)
            current = current[-overlap:] if overlap else []
            fresh = 0
        current += words
        fresh += len(words)
        while len(current) > max_words:
            flush(current[:max_words])
            current = current[max_words - overlap :]
            fresh = len(current) - overlap if overlap else len(current)
    if current and fresh > 0:
        flush(current)
    return chunks


def load_corpus(corpus_dir: Path, max_words: int = 90, overlap: int = 15) -> list[Chunk]:
    """Chunk every ``*.md`` file in a directory. The first ``# `` line is the title."""
    corpus_dir = Path(corpus_dir)
    files = sorted(corpus_dir.glob("*.md"))
    if not files:
        raise FileNotFoundError(f"No .md documents found in {corpus_dir}")
    chunks: list[Chunk] = []
    for path in files:
        raw = path.read_text(encoding="utf-8")
        lines = raw.splitlines()
        title = path.stem.replace("_", " ").title()
        if lines and lines[0].startswith("# "):
            title = lines[0][2:].strip()
            raw = "\n".join(lines[1:])
        chunks.extend(chunk_text(raw, path.stem, title, max_words, overlap))
    return chunks
