"""LLM backends. The agent only needs one method: ``next_step``.

``next_step`` returns raw text that should contain one JSON decision:
    {"action": "tool", "tool": "<name>", "input": {...}}
    {"action": "final", "answer": "<text>"}
The agent validates it, so a backend never has to be trusted.
"""

from __future__ import annotations

import json
import re
from typing import Any, Protocol, Sequence

from .config import PRODUCTS, REGIONS, Settings
from .text import tokenize

MONTHS = {
    m: f"{i:02d}"
    for i, m in enumerate(
        "january february march april may june july august september october november december".split(),
        start=1,
    )
}


class LLMError(Exception):
    """The model backend failed (network, auth, bad response)."""


class LLM(Protocol):
    def next_step(self, question: str, history: Sequence[Any], tools: Sequence[dict]) -> str: ...


SYSTEM_PROMPT = """You are a careful assistant that answers questions using tools.
Reply with ONE JSON object and nothing else, in one of two forms:
{"action": "tool", "tool": "<tool name>", "input": {<arguments>}}
{"action": "final", "answer": "<answer for the user>"}
Rules: use tools for facts, never invent numbers, cite passages as [doc#chunk] when you use
search_docs, and give a final answer as soon as you have enough information."""


def render_prompt(question: str, history: Sequence[Any], tools: Sequence[dict]) -> str:
    lines = ["Tools:"]
    for t in tools:
        lines.append(f"- {t['name']}: {t['description']} Parameters: {json.dumps(t['parameters'])}")
    lines.append(f"\nQuestion: {question}\n")
    for step in history:
        if step.kind == "error":
            lines.append(f"Your previous output was invalid: {step.error}. Reply with valid JSON.")
        else:
            lines.append(f"Action: {step.tool} {json.dumps(step.input)}")
            lines.append(f"Observation: {step.error and 'ERROR: ' + step.error or step.observation}")
    lines.append("\nNext JSON decision:")
    return "\n".join(lines)


# --------------------------------------------------------------------- offline policy


class MockLLM:
    """Deterministic, rule-based planner used for tests, demos and offline CI.

    This is NOT a language model. It routes a question to a tool with regexes and
    writes the answer from the observations, which lets the whole agent, API and
    evaluation stack run without an API key. Set LLM_PROVIDER to use a real model.
    """

    _SALES = re.compile(r"\b(revenue|units|sales)\b", re.I)
    _PERCENT = re.compile(r"(\d+(?:\.\d+)?)\s*%")

    def next_step(self, question: str, history: Sequence[Any], tools: Sequence[dict]) -> str:
        done = [s for s in history if s.kind == "tool"]
        if not done:
            return json.dumps(self._first_action(question))
        used = [s.tool for s in done]
        last = done[-1]
        if last.error:
            return json.dumps({"action": "final", "answer": f"I could not complete this: {last.error}"})
        if (
            used == ["sql_query"]
            and (pct := self._PERCENT.search(question))
            and (value := self._first_number(last.observation)) is not None
        ):
            expr = f"{value} * {pct.group(1)} / 100"
            return json.dumps({"action": "tool", "tool": "calculator", "input": {"expression": expr}})
        return json.dumps({"action": "final", "answer": self._answer(question, done)})

    # -- routing

    def _first_action(self, q: str) -> dict:
        ql = q.lower()
        if self._SALES.search(ql):
            return {"action": "tool", "tool": "sql_query", "input": {"query": self._sql(ql)}}
        if (m := re.search(r"(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)", ql)):
            return self._calc(f"{m.group(2)} * {m.group(1)} / 100")
        if re.search(r"\b(calculate|compute)\b", ql) or re.search(r"what is [\d(]", ql):
            candidates = re.findall(r"[\d(][\d\.\s\+\-\*/\(\)\^]*[\d)]", q)
            if candidates:
                return self._calc(max(candidates, key=len).replace("^", "**").strip())
        return {"action": "tool", "tool": "search_docs", "input": {"query": q, "k": 3}}

    @staticmethod
    def _calc(expression: str) -> dict:
        return {"action": "tool", "tool": "calculator", "input": {"expression": expression}}

    @staticmethod
    def _sql(ql: str) -> str:
        metric = "units" if re.search(r"\bunits\b", ql) else "revenue"
        agg = "AVG" if re.search(r"\b(average|avg|mean)\b", ql) else "SUM"
        group = None
        for col in ("region", "product", "month"):
            if re.search(rf"\b(by|per|each)\s+{col}\b", ql) or re.search(rf"\bwhich\s+{col}\b", ql):
                group = col
        where = []
        for region in REGIONS:
            if re.search(rf"\b{region.lower()}\b", ql):
                where.append(f"region = '{region}'")
        for product in PRODUCTS:
            if re.search(rf"\b{product.lower()}s?\b", ql):
                where.append(f"product = '{product}'")
        for name, num in MONTHS.items():
            if re.search(rf"\b{name}\b", ql):
                where.append(f"month LIKE '%-{num}'")
        alias = f"{agg.lower()}_{metric}"
        select = f"{group}, " if group else ""
        sql = f"SELECT {select}ROUND({agg}({metric}), 2) AS {alias} FROM sales"
        if where:
            sql += " WHERE " + " AND ".join(where)
        if group:
            sql += f" GROUP BY {group}"
            if re.search(r"\b(highest|top|best|most)\b", ql):
                sql += f" ORDER BY {alias} DESC LIMIT 1"
            elif re.search(r"\b(lowest|worst|least)\b", ql):
                sql += f" ORDER BY {alias} ASC LIMIT 1"
            else:
                sql += f" ORDER BY {group}"
        return sql

    # -- answers

    @staticmethod
    def _extractive_answer(question: str, observation: str) -> str:
        """Pick the two retrieved sentences that share the most terms with the question."""
        q_tokens = set(tokenize(question))
        scored = []
        for order, line in enumerate(observation.splitlines()):
            cite, _, body = line.partition("] ")
            for sentence in re.split(r"(?<=[.!?])\s+", body):
                overlap = len(q_tokens & set(tokenize(sentence)))
                if overlap:
                    scored.append((-overlap, order, f"{sentence} {cite}]"))
        if not scored:
            first = observation.splitlines()[0]
            return first
        return " ".join(text for _, _, text in sorted(scored)[:2])

    @staticmethod
    def _first_number(observation: str) -> str | None:
        rows = observation.splitlines()[1:]  # skip the header line
        for row in rows:
            for token in row.split(" | ")[::-1]:  # the aggregate is the last column
                try:
                    float(token)
                    return token
                except ValueError:
                    continue
        return None

    @staticmethod
    def _answer(question: str, done: Sequence[Any]) -> str:
        last = done[-1]
        if last.tool == "search_docs":
            if last.observation.startswith("No relevant"):
                return "I could not find anything relevant in the knowledge base."
            return MockLLM._extractive_answer(question, last.observation)
        if last.tool == "calculator":
            prefix = ""
            if len(done) > 1 and done[-2].tool == "sql_query":
                prefix = f"Query result: {MockLLM._first_number(done[-2].observation)}. "
            return f"{prefix}Result: {last.observation}"
        return "Query result:\n" + last.observation


# --------------------------------------------------------------------- hosted models


class AnthropicLLM:
    """Claude via the Messages API (needs ``httpx``, an API key and network access)."""

    URL = "https://api.anthropic.com/v1/messages"

    def __init__(self, api_key: str, model: str, timeout: float = 30.0) -> None:
        self.api_key, self.model, self.timeout = api_key, model, timeout

    def next_step(self, question: str, history: Sequence[Any], tools: Sequence[dict]) -> str:
        import httpx

        payload = {
            "model": self.model,
            "max_tokens": 512,
            "system": SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": render_prompt(question, history, tools)}],
        }
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        try:
            resp = httpx.post(self.URL, json=payload, headers=headers, timeout=self.timeout)
            resp.raise_for_status()
            return "".join(b.get("text", "") for b in resp.json()["content"])
        except (httpx.HTTPError, KeyError, ValueError) as exc:
            raise LLMError(f"Anthropic request failed: {exc}") from exc


class OpenAICompatibleLLM:
    """Any OpenAI-compatible chat endpoint: OpenAI, Gemini's compat endpoint, Ollama, vLLM."""

    def __init__(self, api_key: str, model: str, base_url: str, timeout: float = 30.0) -> None:
        self.api_key, self.model, self.timeout = api_key, model, timeout
        self.base_url = base_url.rstrip("/")

    def next_step(self, question: str, history: Sequence[Any], tools: Sequence[dict]) -> str:
        import httpx

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": render_prompt(question, history, tools)},
            ],
        }
        try:
            resp = httpx.post(
                f"{self.base_url}/chat/completions",
                json=payload,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"] or ""
        except (httpx.HTTPError, KeyError, IndexError, ValueError) as exc:
            raise LLMError(f"OpenAI-compatible request failed: {exc}") from exc


def build_llm(settings: Settings) -> LLM:
    provider = settings.llm_provider
    if provider == "mock":
        return MockLLM()
    if not settings.llm_api_key or not settings.llm_model:
        raise ValueError("LLM_API_KEY and LLM_MODEL are required for a hosted provider")
    if provider == "anthropic":
        return AnthropicLLM(settings.llm_api_key, settings.llm_model)
    if provider == "openai":
        return OpenAICompatibleLLM(settings.llm_api_key, settings.llm_model, settings.llm_base_url)
    raise ValueError(f"Unknown LLM_PROVIDER: {provider!r}")
