"""Tools the agent may call. Each validates its own input and raises ``ToolError``."""

from __future__ import annotations

import ast
import csv
import math
import operator
import re
import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .retrieval import Retriever


class ToolError(Exception):
    """A recoverable problem with a tool call. The message is shown to the model."""


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict[str, str]  # parameter name -> short description
    fn: Callable[..., str]

    def spec(self) -> dict[str, Any]:
        return {"name": self.name, "description": self.description, "parameters": self.parameters}


class ToolRegistry:
    def __init__(self, tools: list[Tool]) -> None:
        self._tools = {t.name: t for t in tools}

    def names(self) -> list[str]:
        return list(self._tools)

    def specs(self) -> list[dict[str, Any]]:
        return [t.spec() for t in self._tools.values()]

    def call(self, name: str, args: dict[str, Any]) -> str:
        tool = self._tools.get(name)
        if tool is None:
            raise ToolError(f"Unknown tool {name!r}. Available tools: {', '.join(self._tools)}")
        try:
            return tool.fn(**args)
        except TypeError as exc:  # wrong or missing arguments
            raise ToolError(f"Bad arguments for {name}: {exc}") from exc


# --------------------------------------------------------------------- calculator

_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY_OPS = {ast.UAdd: operator.pos, ast.USub: operator.neg}
_FUNCS = {"sqrt": math.sqrt, "abs": abs, "round": round, "log": math.log}
MAX_EXPR_LEN = 200


def _eval_node(node: ast.AST) -> float:
    if isinstance(node, ast.Expression):
        return _eval_node(node.body)
    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return node.value
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPS:
        return _UNARY_OPS[type(node.op)](_eval_node(node.operand))
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OPS:
        left, right = _eval_node(node.left), _eval_node(node.right)
        if isinstance(node.op, ast.Pow) and (abs(right) > 100 or abs(left) > 1e6):
            raise ToolError("Exponent or base too large")
        return _BIN_OPS[type(node.op)](left, right)
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id in _FUNCS
        and not node.keywords
    ):
        return _FUNCS[node.func.id](*[_eval_node(a) for a in node.args])
    raise ToolError("Unsupported expression; use numbers, + - * / ** % and sqrt/abs/round/log")


def calculator(expression: str) -> str:
    """Safely evaluate arithmetic by walking the AST (never ``eval``)."""
    if not isinstance(expression, str) or not expression.strip():
        raise ToolError("expression must be a non-empty string")
    if len(expression) > MAX_EXPR_LEN:
        raise ToolError(f"expression longer than {MAX_EXPR_LEN} characters")
    try:
        tree = ast.parse(expression.strip(), mode="eval")
        value = _eval_node(tree)
    except ToolError:
        raise
    except ZeroDivisionError as exc:
        raise ToolError("Division by zero") from exc
    except (SyntaxError, ValueError, TypeError, OverflowError) as exc:
        raise ToolError(f"Could not evaluate expression: {exc}") from exc
    return f"{value:.10g}"


# --------------------------------------------------------------------- SQL

_FORBIDDEN_SQL = re.compile(
    r"\b(insert|update|delete|drop|alter|create|attach|detach|pragma|replace|vacuum|reindex)\b",
    re.IGNORECASE,
)


def build_sales_db(csv_path: Path) -> tuple[sqlite3.Connection, threading.Lock]:
    """Load the sample CSV into an in-memory SQLite database, then lock it read-only."""
    conn = sqlite3.connect(":memory:", check_same_thread=False)
    conn.execute(
        "CREATE TABLE sales (month TEXT NOT NULL, region TEXT NOT NULL, product TEXT NOT NULL, "
        "units INTEGER NOT NULL, revenue REAL NOT NULL)"
    )
    with open(csv_path, newline="", encoding="utf-8") as fh:
        rows = [
            (r["month"], r["region"], r["product"], int(r["units"]), float(r["revenue"]))
            for r in csv.DictReader(fh)
        ]
    conn.executemany("INSERT INTO sales VALUES (?, ?, ?, ?, ?)", rows)
    conn.commit()
    conn.execute("PRAGMA query_only = ON")  # defence in depth on top of the checks below
    return conn, threading.Lock()


def run_sql(conn: sqlite3.Connection, lock: threading.Lock, query: str, max_rows: int = 50) -> str:
    """Execute exactly one read-only SELECT and return a compact text table."""
    if not isinstance(query, str) or not query.strip():
        raise ToolError("query must be a non-empty string")
    stmt = query.strip().rstrip(";").strip()
    if ";" in stmt:
        raise ToolError("Only a single SQL statement is allowed")
    if not re.match(r"(?is)^(select|with)\b", stmt):
        raise ToolError("Only SELECT queries are allowed")
    if _FORBIDDEN_SQL.search(stmt):
        raise ToolError("Query contains a forbidden keyword; the database is read-only")
    try:
        with lock:
            cursor = conn.execute(stmt)
            columns = [d[0] for d in cursor.description or []]
            rows = cursor.fetchmany(max_rows + 1)
    except sqlite3.Error as exc:
        raise ToolError(f"SQL error: {exc}") from exc
    truncated = len(rows) > max_rows
    lines = [" | ".join(columns)]
    lines += [" | ".join(str(v) for v in row) for row in rows[:max_rows]]
    if truncated:
        lines.append(f"... truncated to {max_rows} rows")
    return "\n".join(lines)


# --------------------------------------------------------------------- factory


def build_registry(retriever: Retriever, sales_csv: Path) -> ToolRegistry:
    conn, lock = build_sales_db(sales_csv)

    def search_docs(query: str, k: int = 3) -> str:
        if not isinstance(query, str) or not query.strip():
            raise ToolError("query must be a non-empty string")
        try:
            k = max(1, min(int(k), 5))
        except (TypeError, ValueError) as exc:
            raise ToolError("k must be an integer") from exc
        hits = retriever.search(query, k=k, mode="hybrid")
        if not hits:
            return "No relevant passages found."
        return "\n".join(f"[{h.chunk.chunk_id}] {h.chunk.text}" for h in hits)

    return ToolRegistry(
        [
            Tool(
                "search_docs",
                "Search the knowledge base (time series, VaR, RAG, agents, REST, SQL, testing, "
                "Docker, Git). Returns passages with [doc#chunk] citations.",
                {"query": "natural-language search query", "k": "number of passages (1-5)"},
                search_docs,
            ),
            Tool(
                "sql_query",
                "Run one read-only SELECT on table sales(month 'YYYY-MM', region, product, "
                "units, revenue). Regions: North, South, East, West. Products: Laptop, Phone, Tablet.",
                {"query": "a single SQL SELECT statement"},
                lambda query: run_sql(conn, lock, query),
            ),
            Tool(
                "calculator",
                "Evaluate an arithmetic expression.",
                {"expression": "e.g. '0.15 * 1200' or 'sqrt(81) + 2'"},
                calculator,
            ),
        ]
    )
