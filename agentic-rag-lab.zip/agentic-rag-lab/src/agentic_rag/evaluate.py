"""Evaluation harness: retrieval quality (BM25 vs dense vs hybrid) and agent behaviour.

Reports numbers as they come out, with the sample size and a paired-bootstrap interval
for the hybrid-vs-BM25 difference, so small-sample noise is visible.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Sequence

import numpy as np

from .config import REPO_ROOT
from .runtime import Runtime

MODES = ("bm25", "dense", "hybrid")


def reciprocal_rank(ranked: Sequence[str], relevant: Sequence[str]) -> float:
    for i, doc in enumerate(ranked, start=1):
        if doc in relevant:
            return 1.0 / i
    return 0.0


def hit_at_k(ranked: Sequence[str], relevant: Sequence[str], k: int) -> float:
    return float(any(d in relevant for d in ranked[:k]))


def paired_bootstrap_ci(
    a: Sequence[float], b: Sequence[float], n_boot: int = 5000, seed: int = 0
) -> tuple[float, float, float]:
    """Mean of (a - b) with a 95% percentile bootstrap interval over questions."""
    diff = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    rng = np.random.default_rng(seed)
    means = diff[rng.integers(0, len(diff), size=(n_boot, len(diff)))].mean(axis=1)
    lo, hi = np.percentile(means, [2.5, 97.5])
    return float(diff.mean()), float(lo), float(hi)


def eval_retrieval(rt: Runtime, cases: list[dict], k: int = 3) -> dict:
    per_mode: dict[str, dict[str, list[float]]] = {}
    for mode in MODES:
        rr, hits = [], []
        for case in cases:
            ranked = rt.retriever.search_docs(case["question"], k=10, mode=mode)
            rr.append(reciprocal_rank(ranked, case["relevant"]))
            hits.append(hit_at_k(ranked, case["relevant"], k))
        per_mode[mode] = {"rr": rr, "hit": hits}
    summary = {
        m: {"hit@k": float(np.mean(v["hit"])), "mrr": float(np.mean(v["rr"]))}
        for m, v in per_mode.items()
    }
    delta = paired_bootstrap_ci(per_mode["hybrid"]["rr"], per_mode["bm25"]["rr"])
    return {"n": len(cases), "k": k, "modes": summary, "hybrid_minus_bm25_mrr": delta}


def eval_agent(rt: Runtime, cases: list[dict]) -> dict:
    rows, ok_tool, ok_ans, ok_status = [], 0, 0, 0
    for case in cases:
        res = rt.agent.run(case["question"])
        tool_ok = res.tools_used == case["expected_tools"]
        ans_ok = all(s.lower() in res.answer.lower() for s in case["answer_contains"])
        ok_tool += tool_ok
        ok_ans += ans_ok
        ok_status += res.status == "ok"
        rows.append({"question": case["question"], "tools": res.tools_used,
                     "tool_ok": tool_ok, "answer_ok": ans_ok, "status": res.status})
    n = len(cases)
    return {"n": n, "tool_accuracy": ok_tool / n, "answer_pass_rate": ok_ans / n,
            "completed_rate": ok_status / n, "rows": rows}


def render_markdown(ret: dict, agent: dict) -> str:
    out = [f"### Retrieval (n={ret['n']} questions, top-{ret['k']} documents)", "",
           f"| Mode | hit@{ret['k']} | MRR |", "|---|---|---|"]
    for mode, m in ret["modes"].items():
        out.append(f"| {mode} | {m['hit@k']:.3f} | {m['mrr']:.3f} |")
    mean, lo, hi = ret["hybrid_minus_bm25_mrr"]
    out += ["", f"Hybrid minus BM25 MRR: {mean:+.3f} (95% paired-bootstrap CI {lo:+.3f} to {hi:+.3f}).", "",
            f"### Agent (n={agent['n']} questions, offline rule-based planner)", "",
            "| Metric | Value |", "|---|---|",
            f"| Correct tool sequence | {agent['tool_accuracy']:.3f} |",
            f"| Answer contains expected facts | {agent['answer_pass_rate']:.3f} |",
            f"| Run completed (status ok) | {agent['completed_rate']:.3f} |"]
    failures = [r for r in agent["rows"] if not (r["tool_ok"] and r["answer_ok"])]
    if failures:
        out += ["", "Agent failures:"] + [f"- {r['question']} -> tools {r['tools']}" for r in failures]
    return "\n".join(out)


def run_evaluation(rt: Runtime, eval_path: Path | None = None, k: int = 3) -> str:
    path = eval_path or REPO_ROOT / "evals" / "qa_set.json"
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return render_markdown(eval_retrieval(rt, data["retrieval"], k), eval_agent(rt, data["agent"]))
