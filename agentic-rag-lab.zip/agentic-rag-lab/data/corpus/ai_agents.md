# AI Agents and Tool Use

An AI agent is a loop in which a language model decides what to do next, calls a tool, observes the result and repeats until it can answer. The popular ReAct pattern interleaves reasoning with actions such as searching documents, running a database query or calling an API.

Tools are described to the model by a name, a description and an input schema. The runtime, not the model, executes tools and returns the observation, so the runtime can validate inputs and enforce permissions.

Reliable agents need guardrails: a maximum number of steps, detection of repeated identical calls, graceful handling of malformed model output and tool errors, read-only access by default, and a full trace of every step for debugging. Frameworks such as LangGraph model the agent as a graph of nodes with shared state; multi-agent systems split work between specialised agents.
