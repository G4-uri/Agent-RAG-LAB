# Git and Team Workflow

Git records snapshots of a project. Work happens on short-lived feature branches, and changes reach the main branch through pull requests that are reviewed and must pass automated checks. Small, focused commits with clear messages, for example conventional commits such as feat: and fix:, make history easy to read and bisect.

Continuous integration (CI) with GitHub Actions runs linting and tests on every push and pull request. Continuous delivery then builds and publishes the container image when main is green.

In Agile teams using Scrum, work is broken into user stories placed on a sprint backlog. The team holds daily stand-ups, a sprint review to demo finished work and a retrospective to improve the process. Jira is a common tool for tracking these stories and bugs.
