# Value at Risk (VaR)

Value at Risk estimates the loss that should not be exceeded with a given confidence over a horizon. A 99% one-day VaR of 1 million means that on 1% of days losses are expected to be larger than 1 million.

Historical simulation takes the empirical quantile of past returns. Parametric VaR assumes a distribution, often normal, which underestimates fat tails. Volatility-filtered methods rescale returns by current volatility so recent turbulence is reflected.

Backtesting counts breaches, the days when the realised loss exceeded VaR. The breach rate should be close to the nominal rate. Kupiec's proportion-of-failures test checks this. A model can look fine overall yet fail in specific periods, for example during the evening demand ramp, so breach rates should also be examined by time of day.
