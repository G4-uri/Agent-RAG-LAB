# Retrieval-Augmented Generation (RAG)

Retrieval-Augmented Generation gives a language model access to external knowledge at answer time instead of relying only on what it memorised during training. This reduces hallucination and lets answers cite sources and stay up to date without retraining.

A basic RAG pipeline has four stages: split documents into chunks, convert chunks to embeddings and store them in an index, retrieve the chunks most relevant to the user question, and pass those chunks to the model as context for generation.

Chunk size matters. Chunks that are too large dilute relevance; chunks that are too small lose context. A small overlap between neighbouring chunks avoids cutting an idea in half. Always return the source of each chunk so the final answer can carry citations.
