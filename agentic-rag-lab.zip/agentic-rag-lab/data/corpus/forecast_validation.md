# Validating Forecasts Honestly

A forecast is only useful if it beats a simple baseline. The naive persistence baseline predicts that the next value equals the last observed value. For seasonal data, the seasonal naive baseline repeats the value from one season ago. Report model error relative to these baselines, for example with MASE (mean absolute scaled error).

Random k-fold cross-validation is wrong for time series because it lets the model train on the future. Use walk-forward validation instead: train on data up to time t, predict t+1 (or a horizon), then roll the window forward and repeat.

Look-ahead leakage is the most common cause of results that look too good. Features such as rolling means must only use past data. When an improvement looks suspiciously large, debug it before celebrating: unit-scaling bugs and leaked targets are frequent culprits.
