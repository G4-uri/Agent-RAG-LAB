# Time Series Basics

A time series is a sequence of observations ordered in time. Three components are usually separated: trend (slow long-run movement), seasonality (a pattern that repeats at a fixed period such as every 24 hours or every 12 months) and noise.

A series is stationary when its mean, variance and autocorrelation do not change over time. Many classical models such as ARMA assume stationarity. Differencing (subtracting the previous value) is the standard way to remove a trend and make a series closer to stationary.

Autocorrelation measures how strongly a value is related to its own past values at a given lag. The autocorrelation function (ACF) plot reveals seasonality as spikes at the seasonal lag. Always inspect residuals after fitting a model: if they still show autocorrelation, the model has missed structure.
