# Designing REST APIs

A REST API exposes resources over HTTP with predictable verbs: GET reads, POST creates or triggers work, PUT replaces, PATCH updates partially and DELETE removes. Responses use status codes that carry meaning: 200 success, 201 created, 400 or 422 invalid input, 401 unauthenticated, 404 not found and 500 server error.

FastAPI builds on Python type hints and Pydantic models. Request bodies are validated automatically, invalid payloads return 422 with a clear error, and an OpenAPI schema with interactive documentation at /docs is generated for free. Flask is a lighter alternative that leaves validation to the developer.

Good practice: validate every input, authenticate with an API key or token, keep handlers thin and put logic in testable functions, return JSON in a consistent shape, and expose a health endpoint for load balancers and container orchestration.
