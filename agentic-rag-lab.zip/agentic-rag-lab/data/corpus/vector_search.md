# Embeddings and Vector Search

An embedding maps text to a dense vector so that texts with similar meaning lie close together. Closeness is usually measured with cosine similarity, which compares direction and ignores vector length. If vectors are normalised to unit length, cosine similarity equals the dot product.

Exact nearest-neighbour search compares the query with every vector, which is fine for thousands of items. At millions of items, approximate nearest neighbour (ANN) indexes such as HNSW trade a little accuracy for large speed gains.

A vector database such as Chroma, Qdrant, Pinecone or Postgres with the pgvector extension stores vectors together with metadata and supports filtering and persistence. Good embeddings come from models trained for retrieval, for example sentence-transformer models or hosted embedding APIs.
