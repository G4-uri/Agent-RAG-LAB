# Hybrid Retrieval

Keyword search and semantic search fail in different ways. BM25 is a lexical ranking function: it scores documents by matching query terms, weighting rare terms more (inverse document frequency) and normalising for document length. It excels at exact names, codes and rare words but misses paraphrases.

Dense retrieval uses embeddings and finds paraphrases, but can miss exact identifiers and rare terms.

Hybrid retrieval combines both rankings. Reciprocal Rank Fusion (RRF) is a simple, robust way to do it: each document receives the sum of 1 / (k + rank) across the rankings, with k commonly set to 60. RRF needs no score calibration between the two systems. Measure the benefit with hit rate and mean reciprocal rank (MRR) on a labelled question set rather than assuming it.
