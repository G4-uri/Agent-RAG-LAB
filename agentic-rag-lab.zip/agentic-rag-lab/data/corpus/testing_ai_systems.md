# Testing AI and LLM Applications

Language model output is non-deterministic, so tests are layered. Unit tests cover the deterministic parts: chunking, ranking, tool input validation and output parsing. To test the agent loop without calling a paid API, replace the model with a scripted fake that returns known responses, including malformed ones.

Evaluation sets measure quality. For retrieval, label which documents answer each question and track hit rate and MRR; for agents, check which tool was chosen and whether the answer contains the expected facts. Run the evaluation in CI so a change that silently makes retrieval worse is caught as a regression.

End-to-end tests drive the real API or UI with tools such as Postman collections, Playwright or Selenium. A QA workflow also includes test plans, regression suites, bug reports with reproduction steps and clear acceptance criteria written from user stories.
