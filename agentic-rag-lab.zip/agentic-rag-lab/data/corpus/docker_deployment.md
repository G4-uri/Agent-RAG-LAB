# Containers and Deployment

Docker packages an application with its dependencies into an image that runs the same way on a laptop, in CI and in the cloud. A Dockerfile lists the steps: start from a slim base image, copy the dependency file and install packages first so that layer is cached, then copy the source code.

Run the process as a non-root user, keep secrets out of the image and pass them as environment variables, and add a HEALTHCHECK so the platform can restart an unhealthy container. A .dockerignore file keeps virtual environments and git history out of the build context.

Cloud platforms such as AWS, Google Cloud Run, Azure or DigitalOcean App Platform can run the container directly. Configuration such as the API key, model name and database location belongs in environment variables following the twelve-factor approach.
