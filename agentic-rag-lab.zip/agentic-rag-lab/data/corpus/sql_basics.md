# SQL Fundamentals

SQL queries data stored in relational tables. SELECT chooses columns, WHERE filters rows, GROUP BY aggregates rows with functions such as SUM, AVG and COUNT, and ORDER BY sorts the result. HAVING filters groups after aggregation, while WHERE filters rows before it.

A JOIN combines tables on a key. An INNER JOIN keeps only matching rows, a LEFT JOIN keeps every row of the left table and fills missing matches with NULL. Indexes speed up lookups on frequently filtered columns at the cost of slower writes.

When an application or an AI agent runs SQL, treat the query as untrusted. Use parameterised queries to prevent SQL injection, connect with a read-only role, allow a single SELECT statement, and limit the number of rows returned. PostgreSQL and MySQL are relational; MongoDB is a document store that suits flexible, nested data.
